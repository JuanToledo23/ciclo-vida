import { Component, OnInit } from '@angular/core';
import { HeaderFooterService } from 'src/app/shared/services/headerFooterService.service';

@Component({
  selector: 'app-mas',
  templateUrl: './mas.component.html'
})
export class MasComponent implements OnInit {

  constructor(public _HeaderFooterService: HeaderFooterService) {
    this._HeaderFooterService.construirHeader('ico-menu', 'Más opciones', false, false, true);
  }


  ngOnInit(): void {
  }

}
